$(function() {
	$('html').each(function() {
		$(this).addClass('base03bg');
	});
});

$('html').attr('style', 'font-size:100%;');



$(function() {
	$('body').each(function() {
		$(this).addClass('base03bg');
	});
});

$('body').attr('text', '#839496');
$('body').attr('style', 'margin:10px;padding:5px;font-size:100%;');



$(function() {
	$('center').each(function() {
		$(this).addClass('');
	});
});

$('center').attr('text', '');
$('center').attr('style', 'margin:0px;padding:0px;font-size:1.0em');

$(function() {
	$('center table').each(function() {
		$(this).addClass('');
	});
});

$('center table').attr('text', '');
$('center table').attr('style', 'margin:0px;padding:0px;font-size:1.2em');

$(function() {
	$('table').each(function() {
		$(this).addClass('');
	});
});

$('table').attr('text', '');
$('table').attr('style', 'margin:1%;padding:0px;font-size:1.2em');




$(function() {
	$('').each(function() {
		$(this).addClass('base03');
	});
});

$('').attr('text', '#002b36');

$(function() {
	$('').each(function() {
		$(this).addClass('base03');
	});
});

$('').attr('text', '#002b36');

$(function() {
	$('').each(function() {
		$(this).addClass('base03');
	});
});

$('').attr('text', '#002b36');

$(function() {
	$('').each(function() {
		$(this).addClass('base03');
	});
});

$('').attr('text', '#002b36');

$(function() {
	$('').each(function() {
		$(this).addClass('base03');
	});
});

$('').attr('text', '#002b36');


$(function() {
	$('').each(function() {
		$(this).addClass('base02');
	});
});

$('').attr('text', '#073642');

$(function() {
	$('').each(function() {
		$(this).addClass('base02');
	});
});

$('').attr('text', '#073642');

$(function() {
	$('').each(function() {
		$(this).addClass('base02');
	});
});

$('').attr('text', '#073642');

$(function() {
	$('').each(function() {
		$(this).addClass('base02');
	});
});

$('').attr('text', '#073642');

$(function() {
	$('').each(function() {
		$(this).addClass('base01');
	});
});

$('').attr('text', '#586e75');

$(function() {
	$('').each(function() {
		$(this).addClass('base01');
	});
});

$('').attr('text', '#586e75');

$(function() {
	$('').each(function() {
		$(this).addClass('base01');
	});
});

$('').attr('text', '#586e75');

$(function() {
	$('').each(function() {
		$(this).addClass('base01');
	});
});

$('').attr('text', '#586e75');

$(function() {
	$('').each(function() {
		$(this).addClass('base00');
	});
});

$('').attr('text', '#657b83');

$(function() {
	$('').each(function() {
		$(this).addClass('base00');
	});
});

$('').attr('text', '#657b83');

$(function() {
	$('').each(function() {
		$(this).addClass('base00');
	});
});

$('').attr('text', '#657b83');

$(function() {
	$('').each(function() {
		$(this).addClass('base00');
	});
});

$('').attr('text', '#657b83');

$(function() {
	$('').each(function() {
		$(this).addClass('base0');
	});
});

$('').attr('text', '#839496');

$(function() {
	$('').each(function() {
		$(this).addClass('base0');
	});
});

$('').attr('text', '#839496');

$(function() {
	$('').each(function() {
		$(this).addClass('base0');
	});
});

$('').attr('text', '#839496');

$(function() {
	$('').each(function() {
		$(this).addClass('base0');
	});
});

$('').attr('text', '#839496');

$(function() {
	$('').each(function() {
		$(this).addClass('base1');
	});
});

$('').attr('text', '#586e75');

$(function() {
	$('').each(function() {
		$(this).addClass('base1');
	});
});

$('').attr('text', '#586e75');

$(function() {
	$('').each(function() {
		$(this).addClass('base1');
	});
});

$('').attr('text', '#586e75');

$(function() {
	$('').each(function() {
		$(this).addClass('base1');
	});
});

$('').attr('text', '#586e75');

$(function() {
	$('').each(function() {
		$(this).addClass('base2');
	});
});

$('').attr('text', '#eee8d5');

$(function() {
	$('').each(function() {
		$(this).addClass('base2');
	});
});

$('').attr('text', '#eee8d5');

$(function() {
	$('').each(function() {
		$(this).addClass('base2');
	});
});

$('').attr('text', '#eee8d5');

$(function() {
	$('').each(function() {
		$(this).addClass('base2');
	});
});

$('').attr('text', '#eee8d5');

$(function() {
	$('h1').each(function() {
		$(this).addClass('base0');
	});
});

$('h1').attr('text', '#fdf6e3');
$('h1').attr('style', 'font-size: 1.3em;');

$(function() {
	$('center h1').each(function() {
		$(this).addClass('base0');
	});
});

$('center h1').attr('text', '#fdf6e3');
$('center h1').attr('style', 'font-size: 2.4em;');


/* doesnt affect anything
$(function() {
	$('center a').each(function() {
		$(this).addClass('base0');
	});
});

$('center a').attr('text', '#fdf6e3');
$('center a').attr('style', 'font-size: 10.1em;');

*/

$(function() {
	$('h2').each(function() {
		$(this).addClass('base0');
	});
});

$('h2').attr('text', '#fdf6e3');
$('h2').attr('style', 'font-size: 1.0em;');

$(function() {
	$('h3').each(function() {
		$(this).addClass('base00');
	});
});

$('h3').attr('style', 'font-size: 1.0em;');

$(function() {
	$('').each(function() {
		$(this).addClass('base3');
	});
});

$('').attr('text', '#fdf6e3');

$(function() {
	$('').each(function() {
		$(this).addClass('base3');
	});
});

$('').attr('text', '#fdf6e3');

$(function() {
	$('i').each(function() {
		$(this).addClass('syellow');
	});
});

$('').attr('text', '#b58900');

$(function() {
	$('pre').each(function() {
		$(this).addClass('');
	});
});

$('').attr('text', '#b58900');
$('pre').attr('style', 'font-size:1.0em;margin:0px;');


$(function() {
	$('pre a').each(function() {
		$(this).addClass('syellow');
	});
});

$('').attr('text', '#b58900');
$('pre a').attr('style', 'font-size:1.0em;margin:0px;');

$(function() {
	$('pre b').each(function() {
		$(this).addClass('');
	});
});

$('').attr('text', '#b58900');
$('pre b').attr('style', 'font-size:1.0em;margin:0px;');

$(function() {
	$('b').each(function() {
		$(this).addClass('');
	});
});

$('').attr('text', '#b58900');
$('b').attr('style', 'font-size:1.0em;margin:0px;');

$(function() {
	$('b a').each(function() {
		$(this).addClass('');
	});
});

$('').attr('text', '#b58900');
$('b a').attr('style', 'font-size:1.0em;margin:0px;text:#111;');


$(function() {
	$('').each(function() {
		$(this).addClass('syellow');
	});
});

$('').attr('text', '#b58900');
$('').attr('style', 'font-size:1.0em;margin:0px;');

$(function() {
	$('blockquote').each(function() {
		$(this).addClass('base02bg');
	});
});

$('').attr('text', '#b58900');
$('blockquote').attr('style', 'font-size:1.0em;padding:8px;');


$(function() {
	$('hr').each(function() {
		$(this).addClass('base0');
	});
});

$('hr').attr('size', '1');

$(function() {
	$('a').each(function() {
		$(this).addClass('base0');
	});
});

$('a').attr('text', '#fdf6e3');
$('a').attr('style', 'font-size: 1.0em;');

$(function() {
	$('').each(function() {
		$(this).addClass('sred');
	});
});

$('').attr('text', '#b58900');


$(function() {
	$('').each(function() {
		$(this).addClass('sred');
	});
});

$('').attr('text', '#b58900');


$(function() {
	$('').each(function() {
		$(this).addClass('sred');
	});
});

$('').attr('text', '#b58900');



$(function() {
	$('').each(function() {
		$(this).addClass('sorange');
	});
});

$('').attr('text', '#cb4b16');

$(function() {
	$('').each(function() {
		$(this).addClass('sorange');
	});
});

$('').attr('text', '#cb4b16');

$(function() {
	$('').each(function() {
		$(this).addClass('sorange');
	});
});

$('').attr('text', '#cb4b16');

$(function() {
	$('').each(function() {
		$(this).addClass('sorange');
	});
});

$('').attr('text', '#cb4b16');

$(function() {
	$('').each(function() {
		$(this).addClass('sred');
	});
});

$('').attr('text', '#dc322f');

$(function() {
	$('').each(function() {
		$(this).addClass('sred');
	});
});

$('').attr('text', '#dc322f');


$(function() {
	$('').each(function() {
		$(this).addClass('sred');
	});
});

$('').attr('text', '#dc322f');


$(function() {
	$('').each(function() {
		$(this).addClass('sred');
	});
});

$('').attr('text', '#dc322f');

$(function() {
	$('').each(function() {
		$(this).addClass('smagenta');
	});
});

$('').attr('text', '#d33682');

$(function() {
	$('').each(function() {
		$(this).addClass('smagenta');
	});
});

$('').attr('text', '#d33682');

$(function() {
	$('').each(function() {
		$(this).addClass('smagenta');
	});
});

$('').attr('text', '#d33682');

$(function() {
	$('').each(function() {
		$(this).addClass('smagenta');
	});
});

$('').attr('text', '#d33682');

$(function() {
	$('').each(function() {
		$(this).addClass('sviolet');
	});
});

$('').attr('text', '#6c71c4');

$(function() {
	$('').each(function() {
		$(this).addClass('sviolet');
	});
});

$('').attr('text', '#6c71c4');

$(function() {
	$('').each(function() {
		$(this).addClass('sviolet');
	});
});

$('').attr('text', '#6c71c4');

$(function() {
	$('').each(function() {
		$(this).addClass('sviolet');
	});
});

$('').attr('text', '#6c71c4');

$(function() {
	$('').each(function() {
		$(this).addClass('sviolet');
	});
});

$('').attr('text', '#6c71c4');

$(function() {
	$('').each(function() {
		$(this).addClass('sblue');
	});
});

$('').attr('text', '#268bd2');

$(function() {
	$('').each(function() {
		$(this).addClass('sblue');
	});
});

$('').attr('text', '#268bd2');

$(function() {
	$('').each(function() {
		$(this).addClass('sblue');
	});
});

$('').attr('text', '#268bd2');

$(function() {
	$('').each(function() {
		$(this).addClass('sblue');
	});
});

$('').attr('text', '#268bd2');

$(function() {
	$('td a').each(function() {
		$(this).addClass('sblue');
	});
});

$('td a').attr('style', 'font-size:1.0em;margin:0px;');

$(function() {
	$('').each(function() {
		$(this).addClass('scyan');
	});
});

$('').attr('text', '#2aa198');

$(function() {
	$('').each(function() {
		$(this).addClass('scyan');
	});
});

$('').attr('text', '#2aa198');

$(function() {
	$('').each(function() {
		$(this).addClass('scyan');
	});
});

$('').attr('text', '#2aa198');

$(function() {
	$('').each(function() {
		$(this).addClass('sgreen');
	});
});

$('').attr('text', '#859900');

$(function() {
	$('').each(function() {
		$(this).addClass('sgreen');
	});
});

$('').attr('text', '#859900');


$(function() {
	$('p').each(function() {
		$(this).addClass('base02bg');
	});
});

$('p').attr('font-size', '1.0em');
$('p').attr('text', '#859900');
$('p').attr('style', 'padding:8px;');


$(function() {
	$('p a').each(function() {
		$(this).addClass('');
	});
});

$('p a').attr('font-size', '1.0em');
$('').attr('text', '');

$(function() {
	$('').each(function() {
		$(this).addClass('sgreen');
	});
});

$('').attr('text', '#859900');


$(function() {
	$('code').each(function() {
		$(this).addClass('sgreen');
	});
});

$('').attr('text', '#859900');
$('code').attr('style', 'margin:0px;');


$(function() {
	$('').each(function() {
		$(this).addClass('sgreen');
	});
});

$('').attr('text', '#859900');
